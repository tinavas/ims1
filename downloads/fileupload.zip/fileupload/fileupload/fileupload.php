<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Tulasi Technologies - PMS</title>

<link rel="stylesheet" href="fileupload/upload.css" type="text/css" />

<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="js/jquery.fileupload.js"></script>

<script type="text/javascript">

$(document).ready(function() {
	$("#fileUpload").fileUpload({
		'uploader': 'fileupload/uploader.swf',
		'cancelImg': 'fileupload/cancel.png',
		'script': 'fileupload/upload.php',
		'folder': 'files',
		'multi': false,
		'displayData': 'speed'
	});

	$("#fileUpload2").fileUpload({
		'uploader': 'fileupload/uploader.swf',
		'cancelImg': 'fileupload/cancel.png',
		'script': 'fileupload/upload.php',
		'folder': 'files',
		'multi': true,
		'buttonText': 'Select Files',
		'checkScript': 'fileupload/check.php',
		'displayData': 'speed',
		'simUploadLimit': 2
	});

	$("#fileUpload3").fileUpload({
		'uploader': 'fileupload/uploader.swf',
		'cancelImg': 'fileupload/cancel.png',
		'script': 'fileupload/upload.php',
		'folder': 'files',
		'fileDesc': 'Image Files',
		'fileExt': '*.jpg;*.jpeg;*.gif;*.png',
		'multi': true,
		'auto': true
	});
});

</script>
</head>

<body>
		<div id="fileUpload3">You have a problem with your javascript</div>
</body>
</html>
